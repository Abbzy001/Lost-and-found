const STORAGE_KEY = "bukLostFoundReports";

const sampleReports = [
  {
    id: crypto.randomUUID(),
    type: "found",
    category: "ID Card",
    itemName: "Black student ID card",
    location: "Faculty of Science",
    date: "2026-09-15",
    description: "Black ID card with a faded BUK logo and student name visible on the back.",
    reporterName: "Maryam Sani",
    contact: "0803 111 2299",
    securityNote: "Kept at Faculty security desk for verification.",
    shareContact: true,
    createdAt: Date.now() - 1000 * 60 * 120,
  },
  {
    id: crypto.randomUUID(),
    type: "lost",
    category: "Mobile",
    itemName: "Samsung Galaxy A54",
    location: "New Site Lecture Hall",
    date: "2026-09-14",
    description: "Blue phone case, cracked screen, with a heart-shaped sticker on the back.",
    reporterName: "Abubakar Musa",
    contact: "0805 883 1021",
    securityNote: "Please report to the main gate security if found.",
    shareContact: true,
    createdAt: Date.now() - 1000 * 60 * 360,
  },
  {
    id: crypto.randomUUID(),
    type: "found",
    category: "Wallet/Keys",
    itemName: "Brown wallet with keys",
    location: "Main Library",
    date: "2026-09-13",
    description: "Brown leather wallet and a set of university gate keys inside a small pouch.",
    reporterName: "Hauwa Ibrahim",
    contact: "0704 444 2701",
    securityNote: "Wallet and keys handed over to library security.",
    shareContact: true,
    createdAt: Date.now() - 1000 * 60 * 540,
  },
  {
    id: crypto.randomUUID(),
    type: "lost",
    category: "Electronics",
    itemName: "Blue power bank",
    location: "New Site",
    date: "2026-09-12",
    description: "Medium-sized blue power bank with a white USB cable attached.",
    reporterName: "Zainab Ali",
    contact: "0903 117 4494",
    securityNote: "Contact reporting desk for return if found.",
    shareContact: true,
    createdAt: Date.now() - 1000 * 60 * 820,
  },
];

function getReports() {
  const stored = localStorage.getItem(STORAGE_KEY);
  if (!stored) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(sampleReports));
    return [...sampleReports];
  }

  try {
    const parsed = JSON.parse(stored);
    return Array.isArray(parsed) && parsed.length ? parsed : [...sampleReports];
  } catch (error) {
    return [...sampleReports];
  }
}

function saveReport(report) {
  const reports = getReports();
  reports.unshift(report);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(reports));
}

function formatDate(value) {
  if (!value) return "Not provided";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleDateString("en-NG", { day: "numeric", month: "short", year: "numeric" });
}

function renderReports() {
  const reportList = document.getElementById("reportList");
  const count = document.getElementById("resultsCount");

  if (!reportList || !count) return;

  const categoryFilter = document.getElementById("filterCategory")?.value || "all";
  const typeFilter = document.getElementById("filterType")?.value || "all";
  const searchInput = document.getElementById("searchInput")?.value.trim().toLowerCase() || "";

  let reports = getReports();

  reports = reports.filter((report) => {
    const matchesCategory = categoryFilter === "all" || report.category === categoryFilter;
    const matchesType = typeFilter === "all" || report.type === typeFilter;
    const haystack = `${report.itemName} ${report.location} ${report.description} ${report.reporterName}`.toLowerCase();
    const matchesSearch = !searchInput || haystack.includes(searchInput);
    return matchesCategory && matchesType && matchesSearch;
  });

  count.textContent = `${reports.length} item${reports.length === 1 ? "" : "s"} match your filters`;

  if (!reports.length) {
    reportList.innerHTML = '<div class="empty-state">No matching report found. Try another category or search term.</div>';
    return;
  }

  const template = document.getElementById("reportCardTemplate");
  reportList.innerHTML = "";

  reports.forEach((report) => {
    const fragment = template.content.cloneNode(true);
    const tag = fragment.querySelector(".tag");
    const badge = fragment.querySelector(".status-badge");
    const itemName = fragment.querySelector(".item-name");
    const itemMeta = fragment.querySelector(".item-meta");
    const description = fragment.querySelector(".description");
    const location = fragment.querySelector(".location");
    const date = fragment.querySelector(".date");
    const reporter = fragment.querySelector(".reporter");
    const contact = fragment.querySelector(".contact");
    const securityNote = fragment.querySelector(".security-note");

    tag.textContent = report.category;
    tag.classList.add(report.type === "found" ? "green" : "blue");

    badge.textContent = report.type === "found" ? "Found" : "Lost";
    badge.classList.add(report.type === "found" ? "found" : "lost");

    itemName.textContent = report.itemName;
    itemMeta.textContent = `${report.type === "found" ? "Recovered item" : "Reported missing"} • ${report.category}`;
    description.textContent = report.description;
    location.textContent = report.location;
    date.textContent = formatDate(report.date);
    reporter.textContent = report.reporterName;
    contact.textContent = report.shareContact ? report.contact : "Contact on request";
    securityNote.textContent = report.securityNote ? `Security note: ${report.securityNote}` : "Security desk coordination pending.";

    reportList.appendChild(fragment);
  });
}

function setDefaultDate() {
  const dateInput = document.getElementById("date");
  if (!dateInput) return;
  dateInput.value = new Date().toISOString().split("T")[0];
}

function handleFormSubmit(event) {
  event.preventDefault();

  const form = event.currentTarget;
  const formData = new FormData(form);

  const report = {
    id: crypto.randomUUID(),
    type: formData.get("reportType") || "lost",
    category: formData.get("category") || "Other",
    itemName: formData.get("itemName") || "Unnamed item",
    location: formData.get("location") || "Not specified",
    date: formData.get("date") || new Date().toISOString().split("T")[0],
    description: formData.get("description") || "No description provided.",
    reporterName: formData.get("reporterName") || "Anonymous",
    contact: formData.get("contact") || "Not provided",
    securityNote: formData.get("securityNote") || "Security desk coordination pending.",
    shareContact: document.getElementById("shareContact")?.checked ?? true,
    createdAt: Date.now(),
  };

  saveReport(report);
  form.reset();
  setDefaultDate();
  renderReports();

  const submitButton = form.querySelector("button[type='submit']");
  if (submitButton) {
    submitButton.textContent = "Report saved";
    setTimeout(() => {
      submitButton.textContent = "Save report";
    }, 1200);
  }
}

function setupReportPage() {
  const form = document.getElementById("reportForm");
  if (form) {
    form.addEventListener("submit", handleFormSubmit);
    setDefaultDate();
  }

  const filterCategory = document.getElementById("filterCategory");
  const filterType = document.getElementById("filterType");
  const searchInput = document.getElementById("searchInput");

  [filterCategory, filterType, searchInput].forEach((element) => {
    element?.addEventListener("input", renderReports);
    element?.addEventListener("change", renderReports);
  });

  renderReports();
}

document.addEventListener("DOMContentLoaded", () => {
  setupReportPage();
});
